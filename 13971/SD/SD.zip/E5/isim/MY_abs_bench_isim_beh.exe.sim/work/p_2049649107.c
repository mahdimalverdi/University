/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
extern char *STD_STANDARD;
extern char *IEEE_P_2592010699;



int work_p_2049649107_sub_343117607_1598434845(char *t1, char *t2, char *t3)
{
    char t4[128];
    char t5[24];
    char t9[8];
    int t0;
    char *t6;
    char *t7;
    char *t8;
    char *t10;
    char *t11;
    char *t12;
    unsigned char t13;
    char *t14;
    char *t15;
    char *t16;
    int t17;
    int t18;
    int t19;
    char *t20;
    int t21;
    int t22;
    int t23;
    char *t24;
    int t25;
    int t26;
    unsigned int t27;
    char *t28;
    int t29;
    unsigned int t30;
    unsigned int t31;
    char *t32;
    unsigned char t33;
    unsigned char t34;
    char *t35;
    char *t36;
    int t37;
    int t38;
    int t39;
    char *t40;

LAB0:    t6 = (t4 + 4U);
    t7 = ((STD_STANDARD) + 384);
    t8 = (t6 + 88U);
    *((char **)t8) = t7;
    t10 = (t6 + 56U);
    *((char **)t10) = t9;
    *((int *)t9) = 0;
    t11 = (t6 + 80U);
    *((unsigned int *)t11) = 4U;
    t12 = (t5 + 4U);
    t13 = (t2 != 0);
    if (t13 == 1)
        goto LAB3;

LAB2:    t14 = (t5 + 12U);
    *((char **)t14) = t3;
    t15 = (t1 + 1168U);
    t16 = *((char **)t15);
    t17 = *((int *)t16);
    t18 = 1;
    t19 = t17;

LAB4:    if (t18 <= t19)
        goto LAB5;

LAB7:    t7 = (t1 + 1168U);
    t8 = *((char **)t7);
    t17 = *((int *)t8);
    t18 = (t17 - 1);
    t7 = (t3 + 0U);
    t19 = *((int *)t7);
    t10 = (t3 + 8U);
    t21 = *((int *)t10);
    t22 = (t18 - t19);
    t27 = (t22 * t21);
    t30 = (1U * t27);
    t31 = (0 + t30);
    t11 = (t2 + t31);
    t13 = *((unsigned char *)t11);
    t33 = (t13 == (unsigned char)3);
    if (t33 != 0)
        goto LAB12;

LAB14:
LAB13:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t17 = *((int *)t8);
    t0 = t17;

LAB1:    return t0;
LAB3:    *((char **)t12) = t2;
    goto LAB2;

LAB5:    t15 = (t1 + 1168U);
    t20 = *((char **)t15);
    t21 = *((int *)t20);
    t22 = (t21 - t18);
    t15 = (t3 + 0U);
    t23 = *((int *)t15);
    t24 = (t3 + 8U);
    t25 = *((int *)t24);
    t26 = (t22 - t23);
    t27 = (t26 * t25);
    t28 = (t3 + 4U);
    t29 = *((int *)t28);
    xsi_vhdl_check_range_of_index(t23, t29, t25, t22);
    t30 = (1U * t27);
    t31 = (0 + t30);
    t32 = (t2 + t31);
    t33 = *((unsigned char *)t32);
    t34 = (t33 == (unsigned char)3);
    if (t34 != 0)
        goto LAB8;

LAB10:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t17 = *((int *)t8);
    t21 = (t17 * 2);
    t7 = (t6 + 56U);
    t10 = *((char **)t7);
    t7 = (t10 + 0);
    *((int *)t7) = t21;

LAB9:
LAB6:    if (t18 == t19)
        goto LAB7;

LAB11:    t17 = (t18 + 1);
    t18 = t17;
    goto LAB4;

LAB8:    t35 = (t6 + 56U);
    t36 = *((char **)t35);
    t37 = *((int *)t36);
    t38 = (t37 * 2);
    t39 = (t38 + 1);
    t35 = (t6 + 56U);
    t40 = *((char **)t35);
    t35 = (t40 + 0);
    *((int *)t35) = t39;
    goto LAB9;

LAB12:    t15 = (t6 + 56U);
    t16 = *((char **)t15);
    t23 = *((int *)t16);
    t15 = (t1 + 1168U);
    t20 = *((char **)t15);
    t25 = *((int *)t20);
    t26 = xsi_vhdl_pow(2, t25);
    t29 = (t23 - t26);
    t15 = (t6 + 56U);
    t24 = *((char **)t15);
    t15 = (t24 + 0);
    *((int *)t15) = t29;
    goto LAB13;

LAB15:;
}

char *work_p_2049649107_sub_2161837159_1598434845(char *t1, char *t2, int t3)
{
    char t4[248];
    char t5[8];
    char t9[8];
    char t12[16];
    char t19[16];
    char *t0;
    char *t6;
    char *t7;
    char *t8;
    char *t10;
    char *t11;
    char *t13;
    char *t14;
    int t15;
    unsigned int t16;
    char *t17;
    char *t18;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    unsigned char t26;
    int t27;
    int t28;
    int t29;
    int t30;
    int t31;
    int t32;
    int t33;
    int t34;
    int t35;
    unsigned int t36;
    unsigned int t37;

LAB0:    t6 = (t4 + 4U);
    t7 = ((STD_STANDARD) + 384);
    t8 = (t6 + 88U);
    *((char **)t8) = t7;
    t10 = (t6 + 56U);
    *((char **)t10) = t9;
    *((int *)t9) = 0;
    t11 = (t6 + 80U);
    *((unsigned int *)t11) = 4U;
    t13 = (t12 + 0U);
    t14 = (t13 + 0U);
    *((int *)t14) = 9;
    t14 = (t13 + 4U);
    *((int *)t14) = 0;
    t14 = (t13 + 8U);
    *((int *)t14) = -1;
    t15 = (0 - 9);
    t16 = (t15 * -1);
    t16 = (t16 + 1);
    t14 = (t13 + 12U);
    *((unsigned int *)t14) = t16;
    t14 = (t4 + 124U);
    t17 = ((IEEE_P_2592010699) + 4024);
    t18 = (t14 + 88U);
    *((char **)t18) = t17;
    t20 = (t14 + 56U);
    *((char **)t20) = t19;
    xsi_type_set_default_value(t17, t19, t12);
    t21 = (t14 + 64U);
    *((char **)t21) = t12;
    t22 = (t14 + 80U);
    *((unsigned int *)t22) = 10U;
    t23 = (t5 + 4U);
    *((int *)t23) = t3;
    t24 = (t6 + 56U);
    t25 = *((char **)t24);
    t24 = (t25 + 0);
    *((int *)t24) = t3;
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t15 = *((int *)t8);
    t26 = (t15 > 0);
    if (t26 != 0)
        goto LAB2;

LAB4:
LAB3:    t7 = (t1 + 1168U);
    t8 = *((char **)t7);
    t15 = *((int *)t8);
    t27 = 1;
    t28 = t15;

LAB5:    if (t27 <= t28)
        goto LAB6;

LAB8:    t7 = (t14 + 56U);
    t8 = *((char **)t7);
    t7 = (t12 + 12U);
    t16 = *((unsigned int *)t7);
    t16 = (t16 * 1U);
    t0 = xsi_get_transient_memory(t16);
    memcpy(t0, t8, t16);
    t10 = (t12 + 0U);
    t15 = *((int *)t10);
    t11 = (t12 + 4U);
    t27 = *((int *)t11);
    t13 = (t12 + 8U);
    t28 = *((int *)t13);
    t17 = (t2 + 0U);
    t18 = (t17 + 0U);
    *((int *)t18) = t15;
    t18 = (t17 + 4U);
    *((int *)t18) = t27;
    t18 = (t17 + 8U);
    *((int *)t18) = t28;
    t29 = (t27 - t15);
    t36 = (t29 * t28);
    t36 = (t36 + 1);
    t18 = (t17 + 12U);
    *((unsigned int *)t18) = t36;

LAB1:    return t0;
LAB2:    t7 = (t6 + 56U);
    t10 = *((char **)t7);
    t27 = *((int *)t10);
    t7 = (t1 + 1168U);
    t11 = *((char **)t7);
    t28 = *((int *)t11);
    t29 = xsi_vhdl_pow(2, t28);
    t30 = (t27 + t29);
    t7 = (t6 + 56U);
    t13 = *((char **)t7);
    t7 = (t13 + 0);
    *((int *)t7) = t30;
    goto LAB3;

LAB6:    t7 = (t6 + 56U);
    t10 = *((char **)t7);
    t29 = *((int *)t10);
    t30 = xsi_vhdl_mod(t29, 2);
    t26 = (t30 == 1);
    if (t26 != 0)
        goto LAB9;

LAB11:    t7 = (t14 + 56U);
    t8 = *((char **)t7);
    t15 = (t27 - 1);
    t7 = (t12 + 0U);
    t29 = *((int *)t7);
    t10 = (t12 + 8U);
    t30 = *((int *)t10);
    t31 = (t15 - t29);
    t16 = (t31 * t30);
    t11 = (t12 + 4U);
    t32 = *((int *)t11);
    xsi_vhdl_check_range_of_index(t29, t32, t30, t15);
    t36 = (1U * t16);
    t37 = (0 + t36);
    t13 = (t8 + t37);
    *((unsigned char *)t13) = (unsigned char)2;

LAB10:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t15 = *((int *)t8);
    t29 = (t15 / 2);
    t7 = (t6 + 56U);
    t10 = *((char **)t7);
    t7 = (t10 + 0);
    *((int *)t7) = t29;

LAB7:    if (t27 == t28)
        goto LAB8;

LAB12:    t15 = (t27 + 1);
    t27 = t15;
    goto LAB5;

LAB9:    t7 = (t14 + 56U);
    t11 = *((char **)t7);
    t31 = (t27 - 1);
    t7 = (t12 + 0U);
    t32 = *((int *)t7);
    t13 = (t12 + 8U);
    t33 = *((int *)t13);
    t34 = (t31 - t32);
    t16 = (t34 * t33);
    t17 = (t12 + 4U);
    t35 = *((int *)t17);
    xsi_vhdl_check_range_of_index(t32, t35, t33, t31);
    t36 = (1U * t16);
    t37 = (0 + t36);
    t18 = (t11 + t37);
    *((unsigned char *)t18) = (unsigned char)3;
    goto LAB10;

LAB13:;
}

char *work_p_2049649107_sub_666642408_1598434845(char *t1, char *t2, char *t3, char *t4)
{
    char t5[128];
    char t6[24];
    char t10[8];
    char t21[16];
    char *t0;
    char *t7;
    char *t8;
    char *t9;
    char *t11;
    char *t12;
    char *t13;
    unsigned char t14;
    char *t15;
    int t16;
    char *t17;
    char *t18;
    int t19;
    int t20;
    unsigned int t22;
    int t23;
    char *t24;
    char *t25;
    int t26;
    unsigned int t27;

LAB0:    t7 = (t5 + 4U);
    t8 = ((STD_STANDARD) + 384);
    t9 = (t7 + 88U);
    *((char **)t9) = t8;
    t11 = (t7 + 56U);
    *((char **)t11) = t10;
    xsi_type_set_default_value(t8, t10, 0);
    t12 = (t7 + 80U);
    *((unsigned int *)t12) = 4U;
    t13 = (t6 + 4U);
    t14 = (t3 != 0);
    if (t14 == 1)
        goto LAB3;

LAB2:    t15 = (t6 + 12U);
    *((char **)t15) = t4;
    t16 = work_p_2049649107_sub_343117607_1598434845(t1, t3, t4);
    t17 = (t7 + 56U);
    t18 = *((char **)t17);
    t17 = (t18 + 0);
    *((int *)t17) = t16;
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    t16 = *((int *)t9);
    t14 = (t16 < 0);
    if (t14 != 0)
        goto LAB4;

LAB6:
LAB5:    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    t16 = *((int *)t9);
    t8 = work_p_2049649107_sub_2161837159_1598434845(t1, t21, t16);
    t11 = (t21 + 12U);
    t22 = *((unsigned int *)t11);
    t22 = (t22 * 1U);
    t0 = xsi_get_transient_memory(t22);
    memcpy(t0, t8, t22);
    t12 = (t21 + 0U);
    t19 = *((int *)t12);
    t17 = (t21 + 4U);
    t20 = *((int *)t17);
    t18 = (t21 + 8U);
    t23 = *((int *)t18);
    t24 = (t2 + 0U);
    t25 = (t24 + 0U);
    *((int *)t25) = t19;
    t25 = (t24 + 4U);
    *((int *)t25) = t20;
    t25 = (t24 + 8U);
    *((int *)t25) = t23;
    t26 = (t20 - t19);
    t27 = (t26 * t23);
    t27 = (t27 + 1);
    t25 = (t24 + 12U);
    *((unsigned int *)t25) = t27;

LAB1:    return t0;
LAB3:    *((char **)t13) = t3;
    goto LAB2;

LAB4:    t8 = (t7 + 56U);
    t11 = *((char **)t8);
    t19 = *((int *)t11);
    t20 = (-(t19));
    t8 = (t7 + 56U);
    t12 = *((char **)t8);
    t8 = (t12 + 0);
    *((int *)t8) = t20;
    goto LAB5;

LAB7:;
}


extern void work_p_2049649107_init()
{
	static char *se[] = {(void *)work_p_2049649107_sub_343117607_1598434845,(void *)work_p_2049649107_sub_2161837159_1598434845,(void *)work_p_2049649107_sub_666642408_1598434845};
	xsi_register_didat("work_p_2049649107", "isim/MY_abs_bench_isim_beh.exe.sim/work/p_2049649107.didat");
	xsi_register_subprogram_executes(se);
}
